<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ProductAndCategory extends Model
{
    use HasFactory;
    protected $table = 'product_and_categories';
}
