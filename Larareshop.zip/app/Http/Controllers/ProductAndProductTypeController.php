<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ProductAndProductTypeController extends Controller
{
    //
}
