import React from 'react'

function Topminibanner(props) {
    return (
        <>
            <img src={props.imgsrc} alt="" className='w-[25vw] h-[11vw]  my-4 rounded-lg shadow-xl' />
        </>
    )
}

export default Topminibanner
