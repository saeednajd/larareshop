import React from 'react'
import Topsection from '../Componnents/Topsection'
import { Head } from '@inertiajs/react'
import Footer from '../Componnents/Footer'
function Shop({ auth, menu }) {
    return (
        <>
            <Head title="shop" />
            <section>
                <Topsection auth={auth} menu={menu}></Topsection>
            </section>
            <section>
                
            </section>
            <section>
                <Footer />
            </section>
        </>
    )
}

export default Shop
